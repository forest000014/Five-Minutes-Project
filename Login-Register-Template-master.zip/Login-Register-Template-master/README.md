<h1>Login Register Template | Dark Version</h1>
Pure CSS and HTML template using Materialize's icons<br>
This is the dark version you can see the light version <a href="https://github.com/MrLolok/Login-Register-Light-Template/">here</a>
<br>
<br>
Website Preview:
<br><br><br>
Login:
<img src="https://image.prntscr.com/image/G-t2n0NTTkmIIQfbMxRpUA.png" title="Login page" />
<br><br>
Register:
<img src="https://image.prntscr.com/image/SILqa3UgRqaTBsYwfhrNUg.png" title="Register page" />
